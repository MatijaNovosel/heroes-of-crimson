using UnityEngine;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using Models;
using Random = System.Random;

namespace HeroesOfCrimson.Utils
{
  public static class Utils
  {
    public static Vector3 GetMousePosition()
    {
      var screenPosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
      if (Camera.main is null) return Vector3.zero;
      var worldPosition = Camera.main.ScreenToWorldPoint(screenPosition);
      return new Vector3(worldPosition.x, worldPosition.y, 0);
    }
    
    public static Vector3 GetPlayerPosition()
    {
      var player = GameObject.Find("Player");
      return !player ? Vector3.zero : player.gameObject.transform.position;
    }
    
    public static bool IsPlayerDead()
    {
      var player = GameObject.Find("Player");
      return player is null;
    }
    
    public static Color FromHex(string hex)
    {
      if (hex.Length<6)
      {
        throw new System.FormatException("Needs a string with a length of at least 6");
      }

      var r = hex.Substring(0, 2);
      var g = hex.Substring(2, 2);
      var b = hex.Substring(4, 2);
      string alpha;
      if (hex.Length >= 8)
        alpha = hex.Substring(6, 2);
      else
        alpha = "FF";

      return new Color((int.Parse(r, NumberStyles.HexNumber) / 255f),
        (int.Parse(g, NumberStyles.HexNumber) / 255f),
        (int.Parse(b, NumberStyles.HexNumber) / 255f),
        (int.Parse(alpha, NumberStyles.HexNumber) / 255f));
    }

    public static float GetAngleFromShootDirection(Vector3 direction)
    {
      return Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
    }

    public static int RandInt(int min, int max)
    {
      var seed = Convert.ToInt32(Regex.Match(Guid.NewGuid().ToString(), @"\d+").Value);
      return new System.Random(seed).Next(min, max);
    }

    public static float CalculatePlayerMovementSpeed(
        float swf,
        bool slowed,
        bool energized
    )
    {
        if (slowed)
        {
            swf = 0f;
            energized = false;
        }

        float tilesPerSecond = 4f + 5.6f * (swf / 75f);
        if (energized) tilesPerSecond *= 1.5f;
        return tilesPerSecond * 1f;
    }
    
    public static float CalculateMoveStepDistance(
        float swf,
        bool slowed,
        bool energized,
        float deltaTime
    )
    {
        float unitsPerSecond = CalculatePlayerMovementSpeed(swf, slowed, energized);
        return unitsPerSecond * deltaTime;
    }
    
    public static float GetDistanceToPlayer(Vector3 from)
    {
      var player = GameObject.Find("Player");
      if (!player) return float.MaxValue;
      return ((Vector2)player.transform.position - (Vector2)from).sqrMagnitude;
    }
    
    public static double RandFloat(float minimum, float maximum)
    { 
      Random random = new Random();
      return Math.Floor(random.NextDouble() * (maximum - minimum) + minimum);
    }

    private static bool _isNegativeStatusEffect(Constants.StatusEffects statusEffect)
    {
      return new List<Constants.StatusEffects>()
      {
        Constants.StatusEffects.ArmorBroken,
        Constants.StatusEffects.Bleeding,
        Constants.StatusEffects.Slowed,
        Constants.StatusEffects.Silenced,
        Constants.StatusEffects.Paralyzed,
        Constants.StatusEffects.Poisoned,
        Constants.StatusEffects.Stunned,
        Constants.StatusEffects.Weak,
        Constants.StatusEffects.Burning,
        Constants.StatusEffects.Sick,
      }.Contains(statusEffect);
    }

    public static StatData GetStatData(Constants.Stats stat)
    {
        var data = new StatData();

        switch (stat)
        {
            case Constants.Stats.MGT:
                data.Name = "Might";
                data.Description = "Increases attack damage by a flat amount. \n\n e.g. 125 base damage + 30 <color=#B04183>MGT</color> = 155 damage";
                data.Color = "B04183";
                break;
            case Constants.Stats.AGI:
                data.Name = "Agility";
                data.Description = "Increases attack speed";
                data.Color = "DD8457";
                break;
            case Constants.Stats.SWF:
                data.Name = "Swiftness";
                data.Description = "Increases movement speed";
                data.Color = "3BAB3B";
                break;
            case Constants.Stats.ARM:
                data.Name = "Armor";
                data.Description = "Decreases incoming damage by a flat amount. \n\n e.g. 100 damage - 30 <color=#7D6D6D>ARM</color> = 70 damage";
                data.Color = "7D6D6D";
                break;
            case Constants.Stats.STR:
                data.Name = "Strength";
                data.Description = "Increases health regeneration. \n\n e.g. HP per second = 2 + 0.2407 * <color=#C54646>STR</color> \n\n 30 <color=#C54646>STR</color> = 9.2 HP/s";
                data.Color = "C54646";
                break;
            case Constants.Stats.WIS:
                data.Name = "Wisdom";
                data.Description = "Increases mana regeneration. \n\n e.g. HP per second = 0.5f + (0.12f * <color=#6488C3>WIS</color>) \n\n 30 <color=#6488C3>WIS</color> = 4.1 MP/s";
                data.Color = "6488C3";
                break;
        }

        return data;
    }

    public static StatusEffectData GetStatusEffectData(Constants.StatusEffects statusEffect)
    {
        var data = new StatusEffectData
        {
            IsNegative = _isNegativeStatusEffect(statusEffect)
        };

        switch (statusEffect)
        {
            case Constants.StatusEffects.Energized:
                data.Name = "Energized";
                data.Description = "Movement speed is increased.";
                break;

            case Constants.StatusEffects.Slowed:
                data.Name = "Slowed";
                data.Description = "Movement speed is reduced.";
                break;

            case Constants.StatusEffects.Silenced:
                data.Name = "Silenced";
                data.Description = "Cannot use abilities.";
                break;

            case Constants.StatusEffects.Damaging:
                data.Name = "Damaging";
                data.Description = "Deals increased damage.";
                break;

            case Constants.StatusEffects.ArmorBroken:
                data.Name = "Armor Broken";
                data.Description = "Defense is greatly reduced.";
                break;

            case Constants.StatusEffects.Healing:
                data.Name = "Healing";
                data.Description = "Gradually restores health over time.";
                break;

            case Constants.StatusEffects.Poisoned:
                data.Name = "Poisoned";
                data.Description = "Takes damage over time.";
                break;

            case Constants.StatusEffects.Bleeding:
                data.Name = "Bleeding";
                data.Description = "Loses health over time when moving.";
                break;

            case Constants.StatusEffects.Armored:
                data.Name = "Armored";
                data.Description = "Defense is increased.";
                break;

            case Constants.StatusEffects.Invincible:
                data.Name = "Invincible";
                data.Description = "Cannot take damage.";
                break;

            case Constants.StatusEffects.Weak:
                data.Name = "Weak";
                data.Description = "Deals reduced damage.";
                break;

            case Constants.StatusEffects.Stunned:
                data.Name = "Stunned";
                data.Description = "Cannot move or act.";
                break;

            case Constants.StatusEffects.Berserk:
                data.Name = "Berserk";
                data.Description = "Greatly increased attack speed and damage taken.";
                break;

            case Constants.StatusEffects.Paralyzed:
                data.Name = "Paralyzed";
                data.Description = "Cannot move but can still act.";
                break;
            
            case Constants.StatusEffects.Burning:
                data.Name = "Burning";
                data.Description = "Losing health over time.";
                break;
            
            case Constants.StatusEffects.Radiance:
                data.Name = "Radiance";
                data.Description = "Burning enemies around you.";
                break;
            
            case Constants.StatusEffects.Sick:
                data.Name = "Sick";
                data.Description = "Unable to heal.";
                break;

            default:
                data.Name = "Unknown";
                data.Description = "No description available.";
                break;
        }

        return data;
    }

    
    public static LineRenderer CreateCircle(
      Transform transform,
      string name,
      float radius,
      Color color,
      int circleSegments = 48
    )
    {
      var go = new GameObject(name);
      go.transform.SetParent(transform);
      go.transform.localPosition = Vector3.zero;

      var lr = go.AddComponent<LineRenderer>();
      lr.useWorldSpace = false;
      lr.loop = true;
      lr.positionCount = circleSegments;
      lr.startWidth = 0.1f;
      lr.endWidth = 0.1f;
      lr.material = new Material(Shader.Find("Sprites/Default"));
      lr.startColor = color;
      lr.endColor = color;
      lr.sortingLayerName = "Collision";

      float angleStep = 2 * Mathf.PI / circleSegments;

      for (int i = 0; i < circleSegments; i++)
      {
        float angle = i * angleStep;
        lr.SetPosition(
          i,
          new Vector3(
            Mathf.Cos(angle) * radius,
            Mathf.Sin(angle) * radius,
            0
          )
        );
      }

      return lr;
    }
  }
}