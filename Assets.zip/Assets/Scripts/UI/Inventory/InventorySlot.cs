using System;
using GameManagement;
using HeroesOfCrimson.Utils;
using Models;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace UI.Inventory
{
    public class InventorySlot : MonoBehaviour, IDropHandler
    {
        public InventoryItem CurrentInventoryItem { get; set; }
        public bool IsHotbar;
        public Constants.ItemTag Tag;
        
        public event Action<Item> OnItemEquipped;
        public event Action<Item> OnItemUnequipped;

        private Image _image;

        private void Awake()
        {
            _image = GetComponent<Image>();
            _image.raycastTarget = true;
        }

        private void SetImage(Sprite sprite) => _image.sprite = sprite;
        
        public void SetItem(InventoryItem newItem)
        {
            var oldItem = CurrentInventoryItem?.ItemInSlot;
            CurrentInventoryItem = newItem;
            if (oldItem != null) OnItemUnequipped?.Invoke(oldItem);
            if (newItem != null) OnItemEquipped?.Invoke(newItem.ItemInSlot);
            RefreshVisual();
        }
        
        public void TryUseConsumable()
        {
            if (CurrentInventoryItem == null || CurrentInventoryItem.ItemInSlot == null) return;
            var item = CurrentInventoryItem.ItemInSlot;
            if (item.tag != Constants.ItemTag.Consumable) return;

            var player = Player.Singleton;
            if (player == null) return;

            switch (item.id)
            {
                case (int)ConsumableItemEnum.HealthPotion:
                {
                    if (Mathf.Approximately(player.MaxHealth, player.CurrentHealth)) return;
                    player.RestoreHp(50);
                    AudioManager.Singleton.PlaySoundCached(Constants.Sounds.UsePotion);
                    break;
                }
                case (int)ConsumableItemEnum.ManaPotion:
                {
                    if (Mathf.Approximately(player.MaxMana, player.CurrentMana)) return;
                    player.RestoreMp(30);
                    AudioManager.Singleton.PlaySoundCached(Constants.Sounds.UsePotion);
                    break;
                }
                case (int)ConsumableItemEnum.PotionOfLife:
                {
                    player.IncreaseMaxHp(5);
                    AudioManager.Singleton.PlaySoundCached(Constants.Sounds.UsePotion);
                    break;
                }
                case (int)ConsumableItemEnum.OldBottleOfGrog:
                {
                    AudioManager.Singleton.PlaySoundCached(Constants.Sounds.Burp);
                    player.SetStatusEffect((int)Constants.StatusEffects.Drunk, 15);
                    CameraMotor.Singleton?.PlayDrunkEffect();
                    break;
                }
                default:
                    return;
            }

            var itemUI = CurrentInventoryItem;

            CurrentInventoryItem = null;
            Destroy(itemUI.gameObject);

            RefreshVisual();
            TooltipManager.Singleton.Hide();
        }
        
        public void RefreshVisual()
        {
            if (CurrentInventoryItem != null)
            {
                SetImage(ResourceCacher.Singleton.InventorySprites[Constants.InventorySlotEnum.Empty]);
                return;
            }

            switch (Tag)
            {
                case Constants.ItemTag.Weapon:
                    SetImage(ResourceCacher.Singleton.InventorySprites[Constants.InventorySlotEnum.Weapon]);
                    break;
                case Constants.ItemTag.Armor:
                    SetImage(ResourceCacher.Singleton.InventorySprites[Constants.InventorySlotEnum.Armor]);
                    break;
                case Constants.ItemTag.Accessory:
                    SetImage(ResourceCacher.Singleton.InventorySprites[Constants.InventorySlotEnum.Accessory1]);
                    break;
                case Constants.ItemTag.None:
                default:
                    SetImage(ResourceCacher.Singleton.InventorySprites[Constants.InventorySlotEnum.Empty]);
                    break;
            }
        }

        public void OnDrop(PointerEventData eventData)
        {
            var droppedItem = eventData.pointerDrag?.GetComponent<InventoryItem>();
            if (droppedItem is null) return;

            droppedItem.MarkDropHandled();

            if (Tag != Constants.ItemTag.None && droppedItem.ItemInSlot.tag != Tag)
            {
                AudioManager.Singleton.PlaySoundCached(Constants.Sounds.Error);
                return;
            }

            var fromSlot = droppedItem.ActiveSlot;
            var toSlot = this;

            var fromInventory = fromSlot.GetComponentInParent<Inventory>();
            var toInventory = GetComponentInParent<Inventory>();

            bool fromLoot = fromInventory != null && fromInventory.IsLootInventory;
            bool toLoot = toInventory != null && toInventory.IsLootInventory;

            AudioManager.Singleton.PlaySoundCached(Constants.Sounds.InventoryMove);

            if (toSlot.CurrentInventoryItem is null)
            {
                MoveItem(droppedItem, toSlot);
                
                if (fromLoot) fromInventory.SyncCurrentLootBagLayout();
                if (toLoot && toInventory != fromInventory) toInventory.SyncCurrentLootBagLayout();
                
                fromInventory?.GetCurrentLootBag()?.TryDestroyIfEmpty();
                toInventory?.GetCurrentLootBag()?.TryDestroyIfEmpty();
                
                return;
            }

            SwapItems(fromSlot, toSlot);
            
            if (fromLoot) fromInventory.SyncCurrentLootBagLayout();
            if (toLoot && toInventory != fromInventory) toInventory.SyncCurrentLootBagLayout();
            
            fromInventory?.GetCurrentLootBag()?.TryDestroyIfEmpty();
            toInventory?.GetCurrentLootBag()?.TryDestroyIfEmpty();
        }
        
        private static void MoveItem(InventoryItem item, InventorySlot targetSlot)
        {
            var previousSlot = item.ActiveSlot;
            previousSlot?.SetItem(null);
            item.ActiveSlot = targetSlot;
            targetSlot.SetItem(item);
            item.transform.SetParent(targetSlot.transform, false);
            ((RectTransform)item.transform).anchoredPosition = Vector2.zero;
        }
        
        private static void SwapItems(InventorySlot slotA, InventorySlot slotB)
        {
            var itemA = slotA.CurrentInventoryItem;
            var itemB = slotB.CurrentInventoryItem;

            slotA.SetItem(itemB);
            slotB.SetItem(itemA);

            if (itemA != null)
            {
                itemA.ActiveSlot = slotB;
                itemA.transform.SetParent(slotB.transform, false);
                ((RectTransform)itemA.transform).anchoredPosition = Vector2.zero;
            }

            if (itemB != null)
            {
                itemB.ActiveSlot = slotA;
                itemB.transform.SetParent(slotA.transform, false);
                ((RectTransform)itemB.transform).anchoredPosition = Vector2.zero;
            }
        }
    }
}
